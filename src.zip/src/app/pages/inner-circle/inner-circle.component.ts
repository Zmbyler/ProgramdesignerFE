import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inner-circle',
  templateUrl: './inner-circle.component.html',
  styleUrls: ['./inner-circle.component.scss']
})
export class InnerCircleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
