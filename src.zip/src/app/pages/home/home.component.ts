import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DefaultComponent } from 'src/app/modal';
import { ApiService } from 'src/app/services/api.service';
import { EventService } from 'src/app/services/event.service';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  user: any;
  bannerData: any;

  constructor(
    private dialog: MatDialog,
    private api: ApiService,
    private event: EventService
  ) {

    this.bannerData = {
      title: 'Get Started Today!',
      // tslint:disable-next-line:max-line-length
      content: 'Our 3 week trial is only $99 and includes: an individualized assessment with Coach Zack, a custom training program and unlimited sessions over a 3 week period, during the adult training time slots.',
      images: ['./assets/images/banner.jpg'],
      buttonText: 'SIGN UP!',
      buttonLink: '/register'
    };
  }

  ngOnInit(): void {

  }


  // OPEN MODAL 1
  // openModal(mtype) {
  //   this.dialog.open(DefaultComponent, {
  //     disableClose: true,
  //     width: '100%',
  //     maxWidth: '400px',
  //     data: { type: mtype }
  //   });
  // }
  // getEmpl() {
  //   this.event.setLoaderEmmit(false);
  //   const opts = { params: new HttpParams({ fromString: '_page=1&_limit=10' }) };
  //   this.api.get('employees', true, opts.params).subscribe(() => {

  //   }, (e) => {
  //     console.log(e);
  //   });
  // }

}
