import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.scss']
})
export class ResultsComponent implements OnInit {

  @Input() data: any;
  @Output() selctOption = new EventEmitter();
  @Output() submitForm = new EventEmitter();
  isSaveProgram: boolean;
  form: FormGroup;

  constructor(
    private router: Router
  ) {
    this.isSaveProgram = false;
  }

  ngOnInit() {
    this.formInit();
  }

  submitFormInit(data) {
    if (this.form.valid) {
      // NEED TO CALL API HERE
      this.router.navigate(['/dashboard']);
    } else {
      this.form.markAllAsTouched();
    }
  }

  saveProgram() {
    if (this.form.valid) {
      this.isSaveProgram = true;
      this.form.addControl('program_name', (new FormControl('', Validators.required)));
    } else {
      this.form.markAllAsTouched();
    }

  }

  generatePDF(data) {
    if (this.form.valid) {
      this.submitForm.emit(data);
    } else {
      console.log(this.form);
      this.form.markAllAsTouched();
    }
  }

  cancel() {

    this.form.removeControl('program_name');
    this.isSaveProgram = false;
  }

  formInit() {
    this.form = new FormGroup({
      block_focus: new FormControl('', Validators.required),
      athlete_profile: new FormControl('', Validators.required),
      assessment_results: new FormControl('', Validators.required),
      training_level: new FormControl('', Validators.required),
      training_level_2: new FormControl('', Validators.required),
      training_level_3: new FormControl('', Validators.required),
      // program_name: new FormControl('', Validators.required),
    });
  }


}
