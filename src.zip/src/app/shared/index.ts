export * from './footer/footer.component';
export * from './header/header.component';
export * from './banner/banner.component';
export * from './results/results.component';

