export const environment = {
  BASE_API_ENDPOINT: 'https://beast.dedicateddevelopers.us/api/',
  BASE_IMAGE_URL: 'https://beast.dedicateddevelopers.us/uploads/',
  production: true
};
